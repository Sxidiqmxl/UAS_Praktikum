class TourismPlace {
  String title;
  String Author;
  String description;
  String Harga;
  String Stock;
  String imageAsset;
  List<String> imageUrls;

  TourismPlace({
    required this.title,
    required this.Author,
    required this.description,
    required this.Harga,
    required this.Stock,
    required this.imageAsset,
    required this.imageUrls,
  });
}

var tourismPlaceList = [
  TourismPlace(
      title: 'BMW M3 Competition',
      Author: 'BMW',
      description:
          'BMW M3 Competition adalah mobil sport bertenaga 503 hp dengan mesin 3.0-liter twin-turbocharged inline-6. Dikenal dengan akselerasi cepat (0-100 km/jam dalam 3,8 detik), handling presisi, dan desain agresif, M3 Competition menawarkan performa tinggi dan kenyamanan dengan fitur teknologi canggih, serta pilihan penggerak roda belakang atau all-wheel drive.',
      Harga: 'Rp3.000.000.000',
      Stock: '15',
      imageAsset: 'images/BMW M3 Competition.jpg',
      imageUrls: [
        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSmvKFWecCNEwBtkDjxJWpUAoskZrYEtTRyHA&s',
        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTl5PESOUZm6sxYBrg7NAKM7YaU1VQdK-YcEw&s',
        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQTEQp4D88zabsnyZxL7vNYemZCSy9YSQXDSg&s'
      ]),
  TourismPlace(
    title: 'Toyota Supra MK4',
    Author: 'Toyota',
    description:
        'Toyota Supra MK4 (A80) adalah mobil sport legendaris yang diluncurkan pada 1993, terkenal dengan mesin 3.0-liter inline-6 turbocharged yang menghasilkan 276 hp. Dikenal dengan performa luar biasa, handling tajam, dan desain ikonik, Supra MK4 menjadi favorit di kalangan penggemar mobil dan dunia modifikasi. Mesin andalannya, bersama dengan platform yang kuat, menjadikannya mobil yang sangat populer di motorsport dan budaya otomotif.',
    Harga: 'Rp3.500.000.000',
    Stock: '50',
    imageAsset: 'images/Toyota Supra MK4.jpg',
    imageUrls: [
      'https://i1.sndcdn.com/artworks-nrr2w59lpfHGtUo5-RFZWSw-t1080x1080.jpg',
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSs9TlmMQlX1CBjQZwunczGYNeQiJekCJ7Wqg&s',
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSdDtZ_QR26uPGgWWsmuyU-oShOSJ1PkLSN1A&s',
    ],
  ),
  TourismPlace(
    title: 'Nissan GT-R34 Nismo',
    Author: 'Nissan',
    description:
        'Nissan GT-R Nismo adalah varian performa tinggi dengan mesin 3.8-liter twin-turbo V6 yang menghasilkan 600 hp. Dikenal dengan akselerasi cepat, handling presisi, dan teknologi canggih, GT-R Nismo menawarkan performa ekstrem di jalan raya dan trek balap.',
    Harga: 'Rp5.000.000.000',
    Stock: '5',
    imageAsset: 'images/Nissan GT-R Nismo.jpg',
    imageUrls: [
      'https://ae01.alicdn.com/kf/Sf23dd27ff72245bdb4205c71e8a64a1fU.jpg_640x640q90.jpg',
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSS24FAqwy-MX74MVhuYi-F5YOVujfqlMlbSQ&s',
      'https://img.cintamobil.com/2019/04/02/radrgpyy/mesin-nisan-skyline-gtr-f48e.jpg',
    ],
  ),
  TourismPlace(
    title: 'Chevrolet Camaro ZL1',
    Author: 'Chevrolet',
    description:
        'Merek produksi Amerika Serikat ini juga ternyata punya mobil balap keren yang jadi andalan. Spesifikasi mesin mobil Chevrolet Camaro ZL1 menggunakan Supercharger 6.2 Liter V8. Tenaga yang dihasilkan bisa mencapai 650 Horsepower. Mobil ini bisa melaju 0 sampai 60 mph hanya dalam waktu 3,5 detik saja!.',
    Harga: 'Rp3.200.000.000',
    Stock: '50',
    imageAsset: 'images/Chevrolet Camaro ZL1.jpg',
    imageUrls: [
      'https://ae01.alicdn.com/kf/Sbbbff1ce381d428d8cd5afb731bacafd8.jpg_640x640q90.jpg',
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRL5gqF4efIxpsj8UYcTru3kD4z8zAfwUSMFA&s',
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS-W6ARNBEDOm15fdoHHTiiwFJx6tZXt8xCbQ&s',
    ],
  ),
  TourismPlace(
    title: 'McLaren 650S GT3',
    Author: 'Charles Dickens',
    description:
        'McLaren menjadi langganan juara F1, tidak heran punya kemampuan merancang mobil balap dengan kecepatan tinggi. Salah satu modelnya adalah McLaren 650S GT3. Mobil ini dibekali dengan mesin 3.8 Liter M838T V8 Twin Turbo. Transmisi menggunakan Six-speed sequential motorsport. Hal ini membuat mobil balap keren ini memiliki performa yang meningkat. Desainnya juga terlihat sangat sporty. Pastinya bisa bersaing dengan mobil-mobil balap merek ternama, misalnya Ferrari, Lamborghini, dan lainnya.',
    Harga: 'Rp2.000.000.000',
    Stock: '2',
    imageAsset: 'images/McLaren 650S GT3.jpg',
    imageUrls: [
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSpl9Unu0GiZ872zQy2FMB3a8PnfxrbRQ3LhA&s',
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR0tz8MynsE3SCTtF-bhzNSLrC4CaDB_45SvA&s',
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTLhXrBMNZsxP64N9CpNJm6Wqyi-qOOgICL3g&s',
    ],
  ),
];
